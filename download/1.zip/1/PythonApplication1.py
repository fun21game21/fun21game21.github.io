import trace
from turtle import *
import random


def fill_data(n):
    f = open("data.txt", "w")
    for i in range(n): 
        f.write(str(random.randint(-200,200)) + " ")     #x
        f.write(str(random.randint(-200,200)) + " ")     #y
        f.write(str(random.randint(1,100)) + "\n")  #r
    f.close()
    print("Success")

def result():
    clear()
    f = open("data.txt").read().split("\n")
    tracer(0)
    for line in f:
        if line == "":
            break
        line = line.split(" ")
        x = int(line[0])
        y = int(line[1])
        r = int(line[2])

        penup()
        goto(x,y)
        pendown()
        circle(r)
        penup()
    update()
    tracer(1)

while True:
    command = input()
    if command == "1":
        n = int(input("count string: "))
        fill_data(n)
    elif command == "2": 
        result()
    else:
        break